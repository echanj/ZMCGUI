import os
import sys
import re
import numpy as np
import subprocess 
from shutil import copyfile
from shutil import move
if not os.path.exists('./pgm/'):
  os.makedirs('./pgm/')
os.system('echo diffuse_h0l.inp > difINPUT')
os.system('echo diffuse_h0l.bin >> difINPUT')
os.system('DZMC ACSALA07_relabel_ZMC.diffuse < difINPUT')
os.system('bin2gray --twofold --norm=20000 diffuse_h0l.bin')
move('diffuse_h0l.pgm','./pgm/'+'diffuse_h0l.pgm')
move('diffuse_h0l.bin','./pgm/'+'diffuse_h0l.bin')
